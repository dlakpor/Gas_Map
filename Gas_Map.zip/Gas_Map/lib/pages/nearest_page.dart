import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:location/location.dart';

class NearestGasStationPage extends StatefulWidget {
  const NearestGasStationPage({super.key});

  @override
  State<NearestGasStationPage> createState() => _NearestGasStationPageState();
}

class _NearestGasStationPageState extends State<NearestGasStationPage> {
  final String _apiKey =
      'AIzaSyB-dU0tt3eHhAhOE_8Uyapf_JxbTPTwhIg'; // Replace with your API key
  final Location _location = Location();

  List<Map<String, dynamic>> _gasStations = [];
  bool _loading = true;
  LatLng? _userLocation;

  @override
  void initState() {
    super.initState();
    _getUserLocation();
  }

  Future<void> _getUserLocation() async {
    try {
      final serviceEnabled = await _location.serviceEnabled();
      if (!serviceEnabled && !await _location.requestService()) {
        setState(() => _loading = false);
        return;
      }

      final permissionGranted = await _location.hasPermission();
      if (permissionGranted == PermissionStatus.denied &&
          await _location.requestPermission() != PermissionStatus.granted) {
        setState(() => _loading = false);
        return;
      }

      final locationData = await _location.getLocation();
      setState(() {
        _userLocation = LatLng(locationData.latitude!, locationData.longitude!);
      });

      if (_userLocation != null) {
        await _fetchNearbyGasStations(_userLocation!);
      }
    } catch (e) {
      debugPrint('Error getting user location: $e');
    }
  }

  Future<void> _fetchNearbyGasStations(LatLng location) async {
    final radius = 10000; // 10 km
    final url =
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${location.latitude},${location.longitude}&radius=$radius&type=gas_station&key=$_apiKey';
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final results = data['results'] as List<dynamic>;
        setState(() {
          _gasStations = results.map((result) {
            final rating = result['rating'];
            return {
              'name': result['name'],
              'rating': (rating is int) ? rating.toDouble() : rating,
              'price_level': result['price_level'],
              'is_open': result['opening_hours']?['open_now'] ?? false,
              'location': LatLng(
                result['geometry']['location']['lat'],
                result['geometry']['location']['lng'],
              ),
              'place_id': result['place_id'],
              'photo_reference':
                  (result['photos'] != null && result['photos'].isNotEmpty)
                      ? result['photos'][0]['photo_reference']
                      : null,
              'address': result['vicinity'],
            };
          }).toList();
        });
      } else {
        debugPrint('Failed to fetch gas stations: ${response.body}');
      }
    } catch (e) {
      debugPrint('Error fetching gas stations: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  void _navigateToGasStation(Map<String, dynamic> gasStation) {
    if (_userLocation != null) {
      Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => MapPages(
          userLocation: _userLocation!,
          gasStation: gasStation,
          apiKey: _apiKey,
        ),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _gasStations.isEmpty
              ? const Center(
                  child: Text(
                    'No gas stations found nearby.',
                    style: TextStyle(fontSize: 16),
                  ),
                )
              : ListView.builder(
                  itemCount: _gasStations.length,
                  itemBuilder: (context, index) {
                    final gasStation = _gasStations[index];
                    return _buildGasStationCard(gasStation);
                  },
                ),
    );
  }

  Widget _buildGasStationCard(Map<String, dynamic> gasStation) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: ListTile(
        leading: gasStation['photo_reference'] != null
            ? Image.network(
                'https://maps.googleapis.com/maps/api/place/photo?maxwidth=100&photoreference=${gasStation['photo_reference']}&key=$_apiKey',
                fit: BoxFit.cover,
              )
            : const Icon(Icons.local_gas_station, size: 40),
        title: Text(gasStation['name'] ?? 'Unknown Gas Station'),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (gasStation['rating'] != null)
              Row(
                children: [
                  Text('Rating: ${gasStation['rating']}'),
                  const SizedBox(width: 8),
                  for (int i = 0;
                      i < (gasStation['rating'] as double).floor();
                      i++)
                    const Icon(Icons.star, size: 16, color: Colors.amber),
                ],
              ),
            Text('Address: ${gasStation['address'] ?? 'No Address Available'}'),
            Text(
              gasStation['is_open'] ? 'Open Now' : 'Closed',
              style: TextStyle(
                color: gasStation['is_open'] ? Colors.green : Colors.red,
              ),
            ),
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.directions),
          onPressed: () => _navigateToGasStation(gasStation),
        ),
      ),
    );
  }
}

class MapPages extends StatelessWidget {
  final LatLng userLocation;
  final Map<String, dynamic> gasStation;
  final String apiKey;

  const MapPages(
      {super.key,
      required this.userLocation,
      required this.gasStation,
      required this.apiKey});

  @override
  Widget build(BuildContext context) {
    final gasStationLocation = gasStation['location'] as LatLng;
    return Scaffold(
      appBar: AppBar(title: Text(gasStation['name'])),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: userLocation,
          zoom: 12.0,
        ),
        polylines: {
          Polyline(
            polylineId: const PolylineId('route'),
            points: [userLocation, gasStationLocation],
            color: Colors.blue,
            width: 5,
          ),
        },
        markers: {
          Marker(
            markerId: const MarkerId('start'),
            position: userLocation,
            infoWindow: const InfoWindow(title: 'Your Location'),
          ),
          Marker(
            markerId: MarkerId(gasStation['name']),
            position: gasStationLocation,
            infoWindow: InfoWindow(title: gasStation['name']),
          ),
        },
      ),
    );
  }
}
