import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:location/location.dart';
import 'package:url_launcher/url_launcher.dart';

class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  LatLng? _currentLocation;
  final Location _location = Location();
  bool _loading = true;
  Set<Marker> _markers = {};
  final String _apiKey = 'AIzaSyB-dU0tt3eHhAhOE_8Uyapf_JxbTPTwhIg';
  Map<String, dynamic>? _selectedGasStation;
  GoogleMapController? _mapController;
  Set<Polyline> _polylines = {};
  bool _isNavigating = false;
  LatLng? _destination;

  @override
  void initState() {
    super.initState();
    _getUserLocation();
    _enableLocationUpdates();
  }

  Future<void> _getUserLocation() async {
    final serviceEnabled = await _location.serviceEnabled();
    if (!serviceEnabled && !await _location.requestService()) {
      setState(() {
        _loading = false;
      });
      return;
    }

    final permissionGranted = await _location.hasPermission();
    if (permissionGranted == PermissionStatus.denied &&
        await _location.requestPermission() != PermissionStatus.granted) {
      setState(() {
        _loading = false;
      });
      return;
    }

    final locationData = await _location.getLocation();
    setState(() {
      _currentLocation =
          LatLng(locationData.latitude!, locationData.longitude!);
      _loading = false;
    });

    if (_currentLocation != null) {
      _fetchNearbyGasStations(_currentLocation!);
    }
  }

  void _enableLocationUpdates() {
    _location.onLocationChanged.listen((locationData) {
      if (locationData.latitude != null && locationData.longitude != null) {
        final newLocation =
            LatLng(locationData.latitude!, locationData.longitude!);

        setState(() {
          _currentLocation = newLocation;
        });

        if (_isNavigating && _destination != null) {
          _mapController?.animateCamera(
            CameraUpdate.newLatLng(newLocation),
          );

          // Update polyline and marker while navigating.
          _drawRoute(_destination!);
        }
      }
    });
  }

  Future<void> _fetchNearbyGasStations(LatLng location) async {
    final radius = 10000; // 10 km
    final url =
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${location.latitude},${location.longitude}&radius=$radius&type=gas_station&key=$_apiKey';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List<dynamic> results = data['results'];

        Set<Marker> markers = results.map((place) {
          final lat = place['geometry']['location']['lat'];
          final lng = place['geometry']['location']['lng'];
          final name = place['name'];

          return Marker(
            markerId: MarkerId(place['place_id']),
            position: LatLng(lat, lng),
            infoWindow: InfoWindow(title: name),
            onTap: () {
              _showGasStationDetails(place);
            },
          );
        }).toSet();

        setState(() {
          _markers = markers;
        });
      } else {
        debugPrint('Failed to fetch places: ${response.body}');
      }
    } catch (e) {
      debugPrint('Error fetching places: $e');
    }
  }

  void _showGasStationDetails(Map<String, dynamic> gasStation) {
    setState(() {
      _selectedGasStation = gasStation;
    });

    final name = gasStation['name'] ?? 'Unknown Gas Station';
    final rating = gasStation['rating']?.toString() ?? 'No Rating';
    final priceLevel = gasStation['price_level']?.toString() ?? 'N/A';
    final isOpen = gasStation['opening_hours']?['open_now'] ?? false;
    final phoneNumber = gasStation['formatted_phone_number'];
    final reviews = gasStation['reviews'] ?? [];
    final images = gasStation['photos'] ?? [];
    final lat = gasStation['geometry']['location']['lat'];
    final lng = gasStation['geometry']['location']['lng'];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return DraggableScrollableSheet(
          expand: false,
          builder: (_, controller) {
            return ListView(
              controller: controller,
              padding: const EdgeInsets.all(16),
              children: [
                // Gas Station Name
                Text(
                  name,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),

                // Rating
                Row(
                  children: [
                    Text(
                      'Rating: $rating',
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(width: 8),
                    for (int i = 0;
                        i < (double.tryParse(rating) ?? 0).floor();
                        i++)
                      const Icon(Icons.star, color: Colors.amber, size: 16),
                  ],
                ),
                const SizedBox(height: 8),

                // Price Level
                Text(
                  'Price Level: $priceLevel',
                  style: const TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 8),

                // Open/Closed Status
                Text(
                  isOpen ? 'Status: Open' : 'Status: Closed',
                  style: TextStyle(
                    fontSize: 16,
                    color: isOpen ? Colors.green : Colors.red,
                  ),
                ),
                const SizedBox(height: 16),

                // Call Button
                if (phoneNumber != null)
                  ElevatedButton.icon(
                    onPressed: () => _makePhoneCall(phoneNumber),
                    icon: const Icon(Icons.phone),
                    label: const Text('Call'),
                  ),
                const SizedBox(height: 16),

                // Images
                if (images.isNotEmpty)
                  SizedBox(
                    height: 150,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: images.length,
                      itemBuilder: (context, index) {
                        final photoReference = images[index]['photo_reference'];
                        final imageUrl =
                            'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=$photoReference&key=$_apiKey';
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: Image.network(imageUrl),
                        );
                      },
                    ),
                  ),
                const SizedBox(height: 16),

                // Reviews
                if (reviews.isNotEmpty)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: reviews.map<Widget>((review) {
                      final author = review['author_name'] ?? 'Anonymous';
                      final text = review['text'] ?? '';
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4.0),
                        child: Text(
                          '"$text" - $author',
                          style: const TextStyle(fontStyle: FontStyle.italic),
                        ),
                      );
                    }).toList(),
                  ),
                const SizedBox(height: 16),

                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pop(context); // Close modal
                    _startNavigation(LatLng(lat, lng));
                  },
                  icon: const Icon(Icons.directions),
                  label: const Text('Start Navigation'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri uri = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      debugPrint('Could not launch $uri');
    }
  }

  void _startNavigation(LatLng destination) {
    setState(() {
      _destination = destination;
      _isNavigating = true;
    });
    _drawRoute(destination);
  }

  void _stopNavigation() {
    setState(() {
      _polylines.clear();
      _destination = null;
      _isNavigating = false;
    });
  }

  Future<void> _drawRoute(LatLng destination) async {
    if (_currentLocation == null) return;

    final url =
        'https://maps.googleapis.com/maps/api/directions/json?origin=${_currentLocation!.latitude},${_currentLocation!.longitude}&destination=${destination.latitude},${destination.longitude}&key=$_apiKey';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final polylinePoints = data['routes'][0]['overview_polyline']['points'];
        final decodedPoints = _decodePolyline(polylinePoints);

        setState(() {
          _polylines = {
            Polyline(
              polylineId: const PolylineId('route'),
              points: decodedPoints,
              color: Colors.blue,
              width: 5,
            ),
          };
        });

        _mapController?.animateCamera(
          CameraUpdate.newLatLngBounds(_getBounds(decodedPoints), 100),
        );
      } else {
        debugPrint('Failed to fetch directions: ${response.body}');
      }
    } catch (e) {
      debugPrint('Error fetching directions: $e');
    }
  }

  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> points = [];
    int index = 0, len = encoded.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int shift = 0, result = 0;
      int b;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1F) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1F) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }

    return points;
  }

  LatLngBounds _getBounds(List<LatLng> points) {
    double southWestLat = points.first.latitude;
    double southWestLng = points.first.longitude;
    double northEastLat = points.first.latitude;
    double northEastLng = points.first.longitude;

    for (var point in points) {
      southWestLat =
          point.latitude < southWestLat ? point.latitude : southWestLat;
      southWestLng =
          point.longitude < southWestLng ? point.longitude : southWestLng;
      northEastLat =
          point.latitude > northEastLat ? point.latitude : northEastLat;
      northEastLng =
          point.longitude > northEastLng ? point.longitude : northEastLng;
    }

    return LatLngBounds(
      southwest: LatLng(southWestLat, southWestLng),
      northeast: LatLng(northEastLat, northEastLng),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _currentLocation == null
              ? const Center(
                  child: Text(
                    'Unable to fetch location.',
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                )
              : GoogleMap(
                  initialCameraPosition: CameraPosition(
                    target: _currentLocation!,
                    zoom: 14.0,
                  ),
                  myLocationEnabled: true,
                  myLocationButtonEnabled: true,
                  markers: _markers,
                  polylines: _polylines,
                  onMapCreated: (controller) => _mapController = controller,
                ),
      floatingActionButton: _isNavigating
          ? FloatingActionButton.extended(
              onPressed: _stopNavigation,
              icon: const Icon(Icons.stop),
              label: const Text('Stop Navigation'),
              backgroundColor: Colors.red,
            )
          : null,
    );
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
