import 'package:flutter/material.dart';

class InformationPage extends StatelessWidget {
  const InformationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About This App'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // App Logo
            Center(
              child: CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage(
                    'C:\Users\hp\Desktop\Gas_Map\image\1.jpg'), // Replace with your logo path
              ),
            ),
            const SizedBox(height: 20),

            // App Description
            const Text(
              'About the App',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'This app helps users find nearby gas stations with ease. Using advanced Google Maps integration, it provides real-time directions, reviews, ratings, and more. Our goal is to simplify your journey and ensure you never run out of fuel!',
              style: TextStyle(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 20),

            // Features
            const Text(
              'Features',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              '''• Locate the nearest gas stations with real-time distance and direction.
              • View ratings, reviews, and images of gas stations.
              • Get precise directions with live navigation.
              • Call gas stations directly for inquiries.
              • User-friendly and intuitive design.''',
              style: TextStyle(fontSize: 16, height: 1.5),
              // ),

              // style: TextStyle(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 20),

            // Author Information
            const Text(
              'About the Author',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Developed by Deazi Lakpor, a professional mobile app developer with over 10 years of experience in creating innovative and user-focused applications. Passionate about solving real-world problems with technology.',
              style: TextStyle(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 20),

            // Contact Information
            const Text(
              'Contact',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: const [
                Icon(Icons.email, color: Colors.blue),
                SizedBox(width: 10),
                Text('Email: 20243935@std.neu.edu.tr',
                    style: TextStyle(fontSize: 16)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: const [
                Icon(Icons.web, color: Colors.blue),
                SizedBox(width: 10),
                Text('Website: www.neu.edu.tr', style: TextStyle(fontSize: 16)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: const [
                Icon(Icons.phone, color: Colors.blue),
                SizedBox(width: 10),
                Text('Phone: +231880333730', style: TextStyle(fontSize: 16)),
              ],
            ),
            const SizedBox(height: 30),

            // Footer
            Center(
              child: Text(
                '© ${DateTime.now().year} neu research & IOT center. All rights reserved.',
                style: const TextStyle(fontSize: 14, color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
