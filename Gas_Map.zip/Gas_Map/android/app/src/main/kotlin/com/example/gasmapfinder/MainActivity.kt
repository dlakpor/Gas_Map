package com.example.gasmapfinder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
